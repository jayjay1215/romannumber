Please confirm the JRE is above 1.5
Run Main.java in package com.romannumeric.busiess via eclipse 
