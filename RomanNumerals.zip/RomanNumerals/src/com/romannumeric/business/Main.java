package com.romannumeric.business;

public class Main {
	/**
	 * Main Test method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String filePath = null;
		if (args.length != 0)
			filePath = args[0];
		try {
			InputFileProcessor.ProcessInputValueFile(filePath);
			InputFileProcessor.MapRomanTockenToIntegerValue();
			OutputFileProcessor.processQuestionsAndReplies();
		} catch (Exception e) {
			System.err.println("Sorry! This inputValue File is not found ");
		}
	}

}
