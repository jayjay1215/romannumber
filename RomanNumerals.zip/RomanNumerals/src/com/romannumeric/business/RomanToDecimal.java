package com.romannumeric.business;

public class RomanToDecimal extends RomanToDecimalConversionRules {
	/**
	 * Convert roman number to decimal
	 * 
	 * @param romanNumber
	 * @return
	 */
	public int romanToDecimal(String romanString) {
		int decimal = 0;
		int lastNumber = 0;
		char[] romanNumeral = romanString.toUpperCase().toCharArray();
		for (int i = romanNumeral.length - 1; i >= 0; i--) {
			Character convertToDecimal = romanNumeral[i];

			switch (convertToDecimal) {
			case 'M':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(1000, lastNumber, decimal);
				lastNumber = 1000;
				break;

			case 'D':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(500, lastNumber, decimal);
				lastNumber = 500;
				break;

			case 'C':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(100, lastNumber, decimal);
				lastNumber = 100;
				break;

			case 'L':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(50, lastNumber, decimal);
				lastNumber = 50;
				break;

			case 'X':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(10, lastNumber, decimal);
				lastNumber = 10;
				break;

			case 'V':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(5, lastNumber, decimal);
				lastNumber = 5;
				break;

			case 'I':
				super.checkRomanCharacterCountValidity(convertToDecimal);
				decimal = processDecimal(1, lastNumber, decimal);
				lastNumber = 1;
				break;
			}
		}
		super.resetLiteralsCounter();
		return decimal;
	}

	/**
	 * processDecimal() applied all subtraction logic and returns the result
	 * 
	 * @param decimal
	 * @param lastNumber
	 * @param lastDecimal
	 * @return
	 */
	public int processDecimal(int decimal, int lastNumber, int lastDecimal) {
		if (lastNumber > decimal) {
			return super.subtractionLogic(lastDecimal, decimal, lastNumber);
		} else {
			return lastDecimal + decimal;
		}
	}
}
