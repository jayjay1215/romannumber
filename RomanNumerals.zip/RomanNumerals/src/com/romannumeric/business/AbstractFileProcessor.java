package com.romannumeric.business;
/**
 * 
 * @author qjie
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class AbstractFileProcessor {
	//define all mappings for conversion values
	static Map<String, String> romanValueMapping = new HashMap<String, String>();//{pish=X, tegj=L, prok=V, glob=I}
	static Map<String, Integer> decimalValues = new HashMap<String, Integer>(); //{pish=10, tegj=50, prok=5, glob=1}
	static Map<String, String> questionsAndReplies = new LinkedHashMap<String, String>();  //{how much is pish tegj glob glob ?}
	static ArrayList<String> queriesValues = new ArrayList<String>(); // [glob glob Silver is 34 Credits, glob prok Gold is 57800 Credits, pish pish Iron is 3910 Credits]
	static Map<String, Float> pairValueList = new HashMap<String, Float>(); //As Float is make sure the 3910/20.0=195.5{Gold=14450, Iron=195.5, Silver=17}
}

