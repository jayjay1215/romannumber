package com.romannumeric.business;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class testing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(3910/20.0);
		Map<String, String> map=new LinkedHashMap<String, String>();
	/*	List list=new ArrayList();
		list.add("how much is pish tegj glob glob ?");
		list.add("how many Credits is glob prok Silver ?");
		list.add("how many Credits is glob prok Gold ?");
		list.add("how many Credits is glob prok Iron ?");
		list.add("how much wood could a woodchuck chuck if a woodchuck could chuck wood ?");
		*/
		map.put("how much is pish tegj glob glob ?", "");
		map.put("how many Credits is glob prok Silver ?", "");
		map.put("how many Credits is glob prok Gold ?", "");
		map.put("how many Credits is glob prok Iron ?", "");
		map.put("how much wood could a woodchuck chuck if a woodchuck could chuck wood ?", "");
		System.out.println(map.entrySet());
		for (Map.Entry<String, String> entry : map.entrySet()) {
			System.out.println(entry.getKey());
		}
		//System.out.println(map);
	}

}
