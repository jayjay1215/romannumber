package com.romannumeric.business;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;

public class InputFileProcessor extends AbstractFileProcessor{
	/**
	 * if file path is specified that is picked up else by default Input inside the same package is pickedup.
	 * Each line is picked up and served to processLine() for processing.
	 * @param filePath
	 * @throws IOException
	 */
	public static void ProcessInputValueFile(String filePath) throws IOException {
		BufferedReader bufferedReader = null;
		if (filePath == null){
			InputStream in = InputFileProcessor.class.getResourceAsStream("/inputValue.txt");
			bufferedReader =new BufferedReader(new InputStreamReader(in));
		}
		else{
			FileReader fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
		}
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			processLine(line);
		}
		bufferedReader.close();
	}

	/**
	 * processline adds the input to various maps<K,T> based on different conditions.
	 * @param line
	 */
	public static void processLine(String line){
		String arr[] = line.split("((?<=:)|(?=:))|( )");
		if (line.endsWith("?")){
			questionsAndReplies.put(line,"");
		}
		else if (arr.length == 3 && arr[1].equalsIgnoreCase("is")){
			romanValueMapping.put(arr[0], arr[arr.length-1]);
		}
		else if(line.toLowerCase().endsWith("credits")){
			queriesValues.add(line);
		}
	}

	/**
	 * Maps tokens to Roman equivalent  
	 * {pish=X, tegj=L, prok=V, glob=I}
	 */
	public static void MapRomanTockenToIntegerValue(){
		Iterator it = romanValueMapping.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry value = (Map.Entry)it.next();
			int integerValue = new RomanToDecimal().romanToDecimal(value.getValue().toString());
			decimalValues.put(value.getKey().toString(), integerValue);
		}
		mapQueryEntities();
	}

	/**
	 * Find the value of elements with queries like [glob glob Silver is 34 Credits]
	 */
	private static void mapQueryEntities(){
		for (int i = 0; i < queriesValues.size(); i++) {
			deCodeQuery(queriesValues.get(i));
		}
	}

	/**
	 * Calculates the values of various elements and appends the same to map pairValueList.
	 * pairValueList :{Gold=14450.0, Iron=195.5, Silver=17.0}
	 * @param query
	 */
	private static void deCodeQuery(String query){
		String array[] = query.split("((?<=:)|(?=:))|( )");
		int index = 0;
		int creditValue = 0; 
		String element= null; 
		String[] valueofElement = null;
		for (int i = 0; i < array.length; i++) {
			if(array[i].toLowerCase().equals("credits")){
				creditValue = Integer.parseInt(array[i-1]);
			}
			if(array[i].toLowerCase().equals("is")){
				index = i-1;
				element = array[i-1];
			}
			valueofElement = java.util.Arrays.copyOfRange(array, 0, index);
		}

		StringBuilder stringBuilder = new StringBuilder();
		for (int j = 0; j < valueofElement.length; j++) {
			stringBuilder.append(romanValueMapping.get(valueofElement[j]));
		}
		float valueOfElementInDecimal = new RomanToDecimal().romanToDecimal(stringBuilder.toString());
		pairValueList.put(element, creditValue/valueOfElementInDecimal);
	}

}
