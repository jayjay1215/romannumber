package com.romanumber.testcase;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.romannumeric.business.RomanToDecimal;

public class RomanToDecimalTest {
	protected String romanNumeral1, romanNumeral2;

	@Before
	public void setUp() throws Exception {
		romanNumeral1 = "MMVI";
		romanNumeral2 = "MMMM";
	}

	/**
	 * Test for Roman to Numeric Conversion.
	 */
	@Test
	public void testRomanToDecimal() {
		RomanToDecimal romanToDecimal = new RomanToDecimal();
		int numericValue = romanToDecimal.romanToDecimal(romanNumeral1);
		Assert.assertEquals(2006, numericValue);
	}

	/**
	 * Non repeatable Roman Numeral repeats more than 3 times in succession
	 * thereby throwing error.
	 */
	@Test
	public void testRomanToDecimalMoreThanThreeTimes() {
		new RomanToDecimal().romanToDecimal(romanNumeral2);
	}

}
