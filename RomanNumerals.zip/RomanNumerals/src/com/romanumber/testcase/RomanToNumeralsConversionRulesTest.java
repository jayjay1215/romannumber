package com.romanumber.testcase;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.romannumeric.business.RomanToDecimalConversionRules;

public class RomanToNumeralsConversionRulesTest {

	protected Character[] characterArray;
	protected Character character;

	@Before
	public void setUp() throws Exception {
		character = 'P';
		characterArray = new Character[]{'I','X','V','L'};
	}
    /**
     * check the character is existed in characterArray
     */
	@Test
	public void testOutputFormatter(){
		boolean result = RomanToDecimalConversionRules.checkIfLiteralPresent(characterArray, character);
		Assert.assertEquals(false, result);
	}

	
	/**
	 * Test to verify the subtraction logic
	 */
	@Test
	public void testSubtractionLogic(){
		int result = RomanToDecimalConversionRules.subtractionLogic(52, 10, 50);
		Assert.assertEquals(42, result, 0);
	}
}
